import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
})

const playfair = Playfair_Display({ 
  subsets: ['latin'],
  variable: '--font-playfair',
})

export const metadata: Metadata = {
  title: 'John Architect - Portfolio',
  description: 'Professional architect portfolio showcasing innovative designs and sustainable architecture',
  keywords: 'architect, portfolio, design, sustainable architecture, urban planning',
  authors: [{ name: 'John Architect' }],
  openGraph: {
    title: 'John Architect - Portfolio',
    description: 'Professional architect portfolio',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}